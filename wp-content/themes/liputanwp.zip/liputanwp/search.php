<?php get_header(); ?>
<div class="content">
<?php get_template_part("template-parts/header/index"); ?>
<?php get_template_part("template-parts/search/index"); ?>
<?php get_template_part("template-parts/footer/index"); ?>
</div>
<button class="btn-top"><i class="icon-top i-button-back-to-top"></i></button>
<?php get_footer(); ?>
jQuery(".icon-search,.search-transparent").click(function() {
	jQuery(".header-search").toggleClass("show");
	jQuery(".search-transparent").toggleClass("show");
	jQuery("body").toggleClass("overflow-hidden");
});
jQuery(".bar").click(function() {
	jQuery(".sidebar-menu").addClass("show");
});
jQuery(".icon-close").click(function() {
	jQuery(".sidebar-menu").removeClass("show");
});


let ias = new InfiniteAjaxScroll('.post', {
  item: '.post-content',
  next: '.paginationpost a:last-child',
  pagination: '.paginationpost',
  spinner: {
    element: '.loading',
    delay: 600,
    show: function(element) {
      element.style.display = 'block'; // default behaviour
    },
    hide: function(element) {
      element.style.display = 'none'; // default behaviour
    }
  }
});
ias.on('nexted', function(event) {
    refreshFsLightbox();
});
  

jQuery('.btn-modif').click(function() {
  jQuery(".time-modified").show();
});
jQuery(document).on("click",".btn-share.copylink",function(e) {
   e.preventDefault();
   var copyText = jQuery(this).attr('data-url');

   document.addEventListener('copy', function(e) {
      e.clipboardData.setData('text/plain', copyText);
      e.preventDefault();
   }, true);
   document.execCommand('copy');  
   jQuery(this).addClass("copied");
   jQuery(this).empty().append("Copied");
 });
jQuery(document).on("click",".btn-image-share.copylink",function(e) {
   e.preventDefault();
   var copyText = jQuery(this).attr('data-url');

   document.addEventListener('copy', function(e) {
      e.clipboardData.setData('text/plain', copyText);
      e.preventDefault();
   }, true);
   document.execCommand('copy');  
 });
if (jQuery("body").hasClass("mobile")) {
  jQuery(document).ready(function() {
    var s = jQuery(".post-content");
    var z = jQuery(".share.hea");
    var h = jQuery("header.header");
    var pos = s.position();            
    jQuery(window).scroll(function() {
      var windowpos = jQuery(window).scrollTop();
      if (windowpos >= pos.top & windowpos <=100000000000000) {
        z.addClass("fixed");
        h.hide();
      } else {
        z.removeClass("fixed"); 
        h.show();
      }
    });
  });
}
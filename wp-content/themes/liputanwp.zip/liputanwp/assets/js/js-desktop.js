jQuery(window).scroll(function() {
	if(jQuery(this).scrollTop() != 0) {
		jQuery('.btn-top').fadeIn();
	} else {
		jQuery('.btn-top').fadeOut();
	}
});
jQuery('.btn-top').click(function() {
	jQuery("html, body").animate({
		scrollTop: 0
	}, 600);
	return false;
});
jQuery('.btn-fixed-search').click(function() {
	jQuery(".fixed-form").toggleClass("show");
});
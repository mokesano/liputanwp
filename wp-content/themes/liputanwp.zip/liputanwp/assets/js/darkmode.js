jQuery( document ).ready(function() {
var x = localStorage.getItem("toggled");
jQuery(".mode").click(function() {
    "dark-mode" != localStorage.toggled ? (
        jQuery("body").toggleClass("darkmode", !0), 
        localStorage.toggled = "dark-mode"
    ) : (
        jQuery("body").toggleClass("darkmode", !1), 
        localStorage.toggled = ""
    )
    
    var y = localStorage.getItem("toggled");
    if ( y == "dark-mode") {
        jQuery(".mode").removeClass("icon-darkmode");
        jQuery(".mode").addClass("icon-lightmode");
    }else{
        jQuery(".mode").removeClass("icon-lightmode");  
        jQuery(".mode").addClass("icon-darkmode");
    }
});

if ( x == "dark-mode") {
    jQuery(".mode").removeClass("icon-darkmode"),
    jQuery(".mode").addClass("icon-lightmode"),
    jQuery("body").addClass("darkmode");
}else{
    jQuery(".mode").removeClass("icon-lightmode"),  
    jQuery(".mode").addClass("icon-darkmode"),
    jQuery("body").removeClass("darkmode"); 
}
});
jQuery(document).ready(function()
{ 
  jQuery('.slider-inline').tinycarousel({ 
    buttons: true, 
    interval: false, 
    intervalTime: 4000, 
    animationTime: 1000 
    });
});
let ias = new InfiniteAjaxScroll('.latest-area', {
  item: '.article-item',
  next: '.pagination a',
  pagination: '.pagination',
  spinner: {
    element: '.loading',
    delay: 600,
    show: function(element) {
      element.style.display = 'block'; // default behaviour
    },
    hide: function(element) {
      element.style.display = 'none'; // default behaviour
    }
  },
  trigger: {
    // element to show as trigger
    element: '.trigger',

    // pass a function which returns true which determines if the load more button should be shown
    when: function(pageIndex) {
      return true;  // default behaviour (always show a trigger)
    },

    // this function is called when the button has to be shown
    show: function(element) {
      element.style.display = 'inline-block'; // default behaviour
    },

    // this function is called when the button has to be hidden
    hide: function(element) {
      element.style.display = 'none'; // default behaviour
    }
  }
});

ias.on('last', function() {
  let el = document.querySelector('.no-more');
  el.style.display = 'block';
})
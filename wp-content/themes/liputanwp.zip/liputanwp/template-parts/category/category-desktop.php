<?php 
if (is_active_sidebar('breaking_area')) :
	dynamic_sidebar('breaking_area');
endif;
?>
<?php if (is_active_sidebar('billboard_area')): ?>
<div class="billboard">
<?php dynamic_sidebar('billboard_area');?>
</div>
<?php endif; ?>
<div class="main">
	<div class="main-container table">
		<div class="article-row">
			<div class="article">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="latest-area">
							<?php 
							if (is_active_sidebar('category_area')) :
								dynamic_sidebar('category_area');
							endif;
							?>
							<?php if (have_posts()): ?>
								<?php while (have_posts()): the_post(); ?>
									<div class="article-item table">
										<div class="article-image media-image">
											<?php echo customthumbnail($post->ID, "image_200_116"); ?>
										</div>
										<div class="article-text">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h3 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h3>
											<div class="summary"><?php echo get_excerpt(100); ?></div>
										</div>
									</div>
								<?php endwhile; ?>
							<?php endif; ?>
							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<img src="<?php echo get_stylesheet_directory_uri() . '/assets/img/loadingbox.gif' ?>" width="32" height="32" alt="Loading">
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
						<?php echo get_next_posts_link("Lihat Lainnya <i class='icon icon-arrow-right'></i>"); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php get_template_part("template-parts/sidebar/index"); ?>
		</div>
	</div>
</div>